#!/usr/bin/perl -w
use strict;


# SELECT ZNAME,ZCDTOTALSTEPS,ZCDCURRENTSTEPS,datetime(ZCDCREATIONDATE+978307200,'unixepoch','localtime'),datetime(ZCDCOMPLETIONDATE+978307200,'unixepoch','localtime'),ZCDISFAV,lower(ZTAG),ZSORTORDER,ZICON FROM ZGOAL;
# SELECT Z_PK,ZNAME FROM ZICON;

my $goaltext = "Crafters to 50|8|8|2018-08-06 10:26:50|2018-08-06 21:27:28|1|heavensward|1|13
Crafter level 50 quests|8|8|2018-08-06 10:27:51|2018-08-08 12:51:52|1|heavensward|2|13
Clean out armory chest|1|0|2018-08-06 13:08:02|2001-01-01 00:00:00|1|heavensward|19|9
Upgrade BLM ironworks gear |1|0|2018-08-06 13:08:45|2001-01-01 00:00:00|1|heavensward|18|12
Research apartment|1|0|2018-08-06 13:11:27|2001-01-01 00:00:00|1|heavensward|17|6
Run a squadrons dungeon |1|0|2018-08-06 13:13:04|2001-01-01 00:00:00|0||4|3
ARR sightseeing|80|0|2018-08-06 13:13:56|2001-01-01 00:00:00|0||3|1
Get ACT working for logging|1|0|2018-08-06 13:16:31|2001-01-01 00:00:00|0||5|8
Try out ACT custom triggers|1|0|2018-08-06 13:16:49|2001-01-01 00:00:00|0||6|8
Kobold beast tribe |3|0|2018-08-06 13:35:13|2001-01-01 00:00:00|0|beasttribe|7|11
Amalj’aa beast tribe|3|0|2018-08-06 13:37:07|2001-01-01 00:00:00|0|beasttribe|8|11
Sahagin beast tribe|3|0|2018-08-06 13:38:19|2001-01-01 00:00:00|0|beasttribe|9|11
Sylph beast tribe |3|0|2018-08-06 13:39:12|2001-01-01 00:00:00|0|beasttribe|10|11
ARR allied beast tribe quests|1|0|2018-08-06 13:40:08|2001-01-01 00:00:00|0|beasttribe|11|11
Clear up low level sidequests|1|0|2018-08-06 13:41:06|2001-01-01 00:00:00|0||12|10
Play Lords of Verminion|1|0|2018-08-07 12:40:02|2001-01-01 00:00:00|0||13|6
Gear miner retainer|1|0|2018-08-07 21:17:44|2001-01-01 00:00:00|0||14|7
Get all to 51 and purge inventory|9|5|2018-08-08 13:19:18|2001-01-01 00:00:00|0|crafting|16|13
Mastercraft book 1 at 58|8|0|2018-08-08 13:23:13|2001-01-01 00:00:00|0|crafting|15|13";

my @icontext = (
"Eureka",
"Chocobo",
"Dungeon",
"Extreme trial",
"Palace of the Dead",
"Something shiny",
"Gathering",
"Raid dungeon",
"Gear",
"Bard job",
"Beast tribes",
"Black mage job",
"Crafting");

for my $line (split /\n/, $goaltext) {
    my @parts = split /\|/, $line;
    print "- name: $parts[0]\n";
    print "  totalSteps: $parts[1]\n";
    print "  currentSteps: $parts[2]\n";
    print "  creationDate: $parts[3]\n";
    my $compDate = $parts[4];
    print "  completionDate: $compDate\n" unless $compDate =~ /^2001/;
    my $isFav = $parts[5];
    my $favString = ($isFav eq "1") ? "true" : "false";
    print "  fav: $favString\n";
    print "  tag: $parts[6]\n" unless $parts[6] eq "";
    print "  sortOrder: $parts[7]\n";
    my $iconIndex = $parts[8] - 1;
    print "  iconName: $icontext[$iconIndex]\n";
}
